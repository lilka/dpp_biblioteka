s is python library. Created for lesson on PWr W4 DPP.
